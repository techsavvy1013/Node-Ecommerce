export function customerDistance() {
  const calculateDistance = Math.floor(Math.random() * 1000) + 100;
  return calculateDistance;
}
