import React from 'react';
export const MinusSquareO = (props) => (
  <svg {...props} viewBox='64 -65 897 897'>
    <g>
      <path
        d='M888 760v0v0v-753v0h-752v0v753v0h752zM888 832h-752q-30 0 -51 -21t-21 -51v-753q0 -29 21 -50.5t51 -21.5h753q29 0 50.5 21.5t21.5 50.5v753q0 30 -21.5 51t-51.5 21v0zM732 347h-442q-14 0 -25 10.5t-11 25.5v0q0 15 11 25.5t25 10.5h442q14 0 25 -10.5t11 -25.5v0
  q0 -15 -11 -25.5t-25 -10.5z'
        fill='currentColor'
      />
    </g>
  </svg>
);
