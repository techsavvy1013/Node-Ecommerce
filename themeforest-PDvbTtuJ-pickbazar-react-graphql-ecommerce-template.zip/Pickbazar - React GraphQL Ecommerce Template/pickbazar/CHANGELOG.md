version: 3.2.0

1. Bump dependency (nextjs v9.5) use redirect functionality.
2. Add Separate Restaurant package.
3. Introduce New Mobile layout.
4. Fix some code and design issues.
